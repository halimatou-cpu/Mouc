<?php
        
        $host = 'localhost'; 
		$login= ''; 
		$mdp = ''; 
		$dbname = '';
        
