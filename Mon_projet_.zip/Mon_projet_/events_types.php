<title>Liste des types d'événements</title>
<?php
	include("session.php");
?>
	<div style="position: relative; top: 100px; left: 33%;">
		<a href="liste_event_ouverts_inscription.php" class="btn btn-default">Liste des événements ouverts</a>
		<a href="liste_event_fermes_inscription.php" class="btn btn-default">Liste des événements fermés</a>
	</div>