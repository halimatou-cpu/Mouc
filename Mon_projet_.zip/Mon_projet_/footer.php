<!-- <p>
    <a href="mailto:machin@bidule.com"><em>Envoyez nous un e-mail pour plus d'info ou toute suggestion ou question en
            cliquant ici !</em> </a>
</p> -->

</body>

</html>