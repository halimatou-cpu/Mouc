<title>Afficher par</title>
<?php
	include("session.php");
?>
<div style="position: absolute; top: 100px; left: 33%;">
    <a href="liste_parE.php" class="btn btn-default">Afficher par évènement</a>
   
</div>